//
//  ViewController.swift
//  Rapiit
//
//  Created by JBorjas on 10/25/20.
//  Copyright © 2020 JBorjas. All rights reserved.
//

import UIKit
import WebKit
import CoreLocation
import os.log
import Firebase

final class ViewController: UIViewController,CLLocationManagerDelegate{
    // MARK: - outlets
    @IBOutlet weak var backButton: UIBarButtonItem!
    @IBOutlet weak var forwardButton: UIBarButtonItem!
    
    // MARK: - Private
    private let searchBar = UISearchBar()
    private var webView: WKWebView!
    
    var manager:CLLocationManager!
    
    override func loadView(){
        webView = WKWebView()
        webView.navigationDelegate = self
        view = webView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        manager = CLLocationManager()
        manager.delegate = self // Hace el controlador delegado de CLLocationManager
        manager.desiredAccuracy = kCLLocationAccuracyBest // Elige el grado de precisión
        manager.requestAlwaysAuthorization() // Solicita la autorización
        manager.startUpdatingLocation() // Inicia la localización
        
        // Navigation buttons
       // backButton.isEnabled = false
       // forwardButton.isEnabled = false
        // search bar
        //self.navigationItem.titleView = searchBar
        //searchBar.delegate = self
        
        // Web view
        let webViewPrefs = WKPreferences()
        webViewPrefs.javaScriptEnabled = true
        webViewPrefs.javaScriptCanOpenWindowsAutomatically = true
        let webViewConf =  WKWebViewConfiguration()
        webViewConf.preferences = webViewPrefs
        
        webView = WKWebView(frame: view.frame, configuration: webViewConf)
        webView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        webView.scrollView.keyboardDismissMode = .onDrag
        webView.configuration.preferences.javaScriptEnabled = true
        view.addSubview(webView)
        
        let token = Messaging.messaging().fcmToken
        print("FCM token: \(token ?? "")")
        
        load(url: "https://rapiit.xyz/Rapiit/index.php?datos="+"\(token ?? "")")
        //hideNavigationBar()
    }

    @IBAction func backButtonAction(_ sender: Any) {
        webView.goBack()
    }
    
    @IBAction func forwardButtonAction(_ sender: Any) {
        webView.goForward()
    }
    
    // MARK: - Private methods
    
    private func load(url: String){
        webView.load(URLRequest(url: URL(string: url)!))
    }
    
    private func hideNavigationBar(){
        // Hide the navigation bar on the this view controller
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        
    }
    
    func locationManager(manager:CLLocationManager, didUpdateLocations locations:[AnyObject]) {
        //println("locations = \(locations)") // Imprime las localizaciones
        //gpsResult.text = "success" // Cambia el texto del label
    }
    
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if navigationAction.navigationType == WKNavigationType.linkActivated{
            os_log("Link was clicked: %@", log: OSLog.default, type: .debug, navigationAction.request.url?.absoluteString ?? "")
            webView.load(navigationAction.request)
        }
        decisionHandler(.allow)
    }
}

// MARK: - UISearchBarDelegate
extension ViewController: UISearchBarDelegate{
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.endEditing(true)
    }
}

// MARK: - WKNavigationDelegate
extension ViewController: WKNavigationDelegate{
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        
        backButton.isEnabled = webView.canGoBack
        forwardButton.isEnabled = webView.canGoForward
    }
}

